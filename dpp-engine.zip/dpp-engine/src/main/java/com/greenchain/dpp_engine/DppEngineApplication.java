package com.greenchain.dpp_engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DppEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(DppEngineApplication.class, args);
	}

}
